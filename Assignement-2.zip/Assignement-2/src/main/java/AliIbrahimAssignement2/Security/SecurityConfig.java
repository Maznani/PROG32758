package AliIbrahimAssignement2.Security;

public class SecurityConfig {
}
