package AliIbrahimAssignement2.controllers;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

// import statements
@RestController
@RequestMapping("/books")
public class BookController {

}
