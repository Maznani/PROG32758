package AliIbrahimAssignement2.DataBase;

import org.springframework.stereotype.Service;


@Service
public class DatabaseAccess {


}
