package AliIbrahimAssignement2.beans;

public class ErrorMessage {
}
