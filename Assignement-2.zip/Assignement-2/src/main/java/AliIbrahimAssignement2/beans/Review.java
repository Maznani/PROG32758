package AliIbrahimAssignement2.beans;

import javax.persistence.*;

@Entity
@Table(name = "reviews") // Make sure the table name is correct in your database.
public class Review {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "book_id")
    private Book book;

    private String comment;
    private Integer rating;


}
