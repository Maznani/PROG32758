package com.Exercise5.java;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.ui.Model;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

@Controller
@SessionAttributes("messages")
public class MessageController {

    @GetMapping("/")
    public String index(Model model, HttpSession session) {
        List<String> messages = (List<String>) session.getAttribute("messages");
        if (messages == null) {
            messages = new ArrayList<>();
            session.setAttribute("messages", messages);
        }
        model.addAttribute("messages", messages);
        return "index";
    }

    @PostMapping("/saveMessage")
    public String saveMessage(@RequestParam String message, HttpSession session) {
        List<String> messages = (List<String>) session.getAttribute("messages");
        messages.add(message);
        session.setAttribute("messages", messages);
        return "redirect:/";
    }

    @PostMapping("/destroy")
    public String destroySession(SessionStatus status) {
        status.setComplete();
        return "redirect:/";
    }
}
